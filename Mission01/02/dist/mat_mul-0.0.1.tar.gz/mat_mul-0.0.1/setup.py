from setuptools import setup
setup(
    name='mat_mul',        # 项目名
    version='0.0.1',       # 版本号
    packages=['mat_mul', 'test'],   # 包括在安装包内的Python包
    include_package_data=True
)
