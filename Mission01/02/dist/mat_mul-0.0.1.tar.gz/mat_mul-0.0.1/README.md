# Python matmul

## 项目运行
1. 先cmake . 再make生成matmul.cpython-39-x86_64-linux-gnu.so, 再将该文件放到mat_mul文件夹下.
2. python setup.py sdist